#!/usr/bin/env bash
set -e
python scraper.py
python bot.py
